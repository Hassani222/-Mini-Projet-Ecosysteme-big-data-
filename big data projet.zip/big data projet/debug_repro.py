import os
import re
import random
from collections import Counter
from datetime import datetime, timedelta
from operator import add
from pathlib import Path

from pyspark.sql import SparkSession, Row

os.environ['PYSPARK_PYTHON'] = r'C:\Users\DELL\AppData\Local\Programs\Python\Python312\python.exe'
os.environ['PYSPARK_DRIVER_PYTHON'] = r'C:\Users\DELL\AppData\Local\Programs\Python\Python312\python.exe'

spark = (
    SparkSession.builder
    .appName('LogStorm')
    .master('local[*, 4]')
    .config('spark.driver.memory', '2g')
    .config('spark.python.worker.faulthandler.enabled', 'true')
    .config('spark.sql.shuffle.partitions', '8')
    .config('spark.ui.showConsoleProgress', 'false')
    .getOrCreate()
)
sc = spark.sparkContext
sc.setLogLevel('ERROR')

DATA_DIR = Path('data')
DATA_DIR.mkdir(exist_ok=True)
LOG_PATH = DATA_DIR / 'app_logs.log'

SERVICES = {
    'api-gateway': 30, 'auth-service': 15, 'order-service': 18, 'payment-service': 12,
    'inventory-service': 10, 'notification-service': 8, 'user-service': 7,
}
LEVELS = {'INFO': 78, 'DEBUG': 8, 'WARN': 9, 'ERROR': 5}
HOURLY_TRAFFIC = [2,1,1,1,1,2,3,5,8,9,9,9,8,9,9,9,8,7,6,5,4,4,3,2]
ERROR_CATEGORIES = {
    'TimeoutError': (20, None),
    'DatabaseError': (24, ['order-service', 'payment-service', 'inventory-service', 'user-service']),
    'NullPointerException': (14, None),
    'AuthenticationError': (12, ['auth-service', 'api-gateway', 'user-service']),
    'ValidationError': (10, None),
    'ServiceUnavailable': (8, ['api-gateway', 'notification-service', 'order-service']),
    'PaymentDeclinedError': (8, ['payment-service']),
    'OutOfMemoryError': (4, None),
}
OTHER_CATEGORIES = {
    'INFO': ['HttpRequest', 'UserLogin', 'OrderCreated', 'CacheHit', 'JobCompleted'],
    'WARN': ['SlowQuery', 'HighLatency', 'RetryAttempt', 'DeprecatedApi'],
    'DEBUG': ['CacheLookup', 'SqlQuery'],
}
MESSAGES = {
    'TimeoutError': ['Upstream call exceeded 5000ms', 'Read timed out after 30s', 'Gateway timeout while calling downstream service'],
    'DatabaseError': ['Connection pool exhausted (max=50)', "Deadlock detected while updating table 'orders'", "Lock wait timeout exceeded on table 'stock'"],
    'NullPointerException': ["Cannot invoke 'getId()' because 'customer' is null", 'Null reference in CartMapper.toDto'],
    'AuthenticationError': ['Invalid JWT signature', 'Access token expired', 'Too many failed login attempts'],
    'ValidationError': ["Field 'email' is malformed", 'Quantity must be a positive integer', "Missing required field 'address'"],
    'ServiceUnavailable': ['HTTP 503 returned by downstream service', 'Circuit breaker OPEN for inventory-service'],
    'PaymentDeclinedError': ['Card declined by issuer', 'Insufficient funds', '3-D Secure authentication failed'],
    'OutOfMemoryError': ['Java heap space', 'GC overhead limit exceeded'],
    'HttpRequest': ['GET /api/v1/products 200', 'POST /api/v1/orders 201', 'GET /api/v1/users/me 200', 'PUT /api/v1/cart 200'],
    'UserLogin': ['User authenticated successfully'],
    'OrderCreated': ['Order persisted with status PENDING'],
    'CacheHit': ['Cache hit for key product:*'],
    'JobCompleted': ['Scheduled job finished successfully'],
    'SlowQuery': ['Query took longer than 2000ms'],
    'HighLatency': ['p95 latency above SLO (800ms)'],
    'RetryAttempt': ['Retrying request (attempt 2/3)'],
    'DeprecatedApi': ['Call to deprecated endpoint /api/v0/orders'],
    'CacheLookup': ['Looking up key in Redis'],
    'SqlQuery': ['SELECT executed in 12ms'],
}
INCIDENT = {'service': 'payment-service', 'category': 'DatabaseError', 'start': datetime(2026, 10, 20, 14, 10), 'minutes': 15, 'n_errors': 1500}


def generate_logs(path, n_events=300_000, seed=42):
    rng = random.Random(seed)
    services, service_w = list(SERVICES), list(SERVICES.values())
    levels, level_w = list(LEVELS), list(LEVELS.values())
    DAY = datetime(2026, 10, 20)

    def random_ts():
        hour = rng.choices(range(24), weights=HOURLY_TRAFFIC)[0]
        return DAY + timedelta(hours=hour, seconds=rng.random() * 3600)

    def error_category(service):
        cats = [c for c, (_, allowed) in ERROR_CATEGORIES.items() if allowed is None or service in allowed]
        return rng.choices(cats, weights=[ERROR_CATEGORIES[c][0] for c in cats])[0]

    events = []
    for _ in range(n_events):
        level = rng.choices(levels, weights=level_w)[0]
        service = rng.choices(services, weights=service_w)[0]
        category = error_category(service) if level == 'ERROR' else rng.choice(OTHER_CATEGORIES[level])
        events.append((random_ts(), level, service, category))
    for _ in range(INCIDENT['n_errors']):
        ts = INCIDENT['start'] + timedelta(seconds=rng.random() * INCIDENT['minutes'] * 60)
        events.append((ts, 'ERROR', INCIDENT['service'], INCIDENT['category']))
    events.sort(key=lambda e: e[0])

    lines = []
    by_level, err_cat, err_svc, noise = Counter(), Counter(), Counter(), Counter()
    for ts, level, service, category in events:
        if category == 'TimeoutError':
            latency = rng.randint(5000, 30000)
        elif category in ('SlowQuery', 'HighLatency'):
            latency = rng.randint(800, 5000)
        else:
            latency = int(rng.lognormvariate(3.8, 0.7))
        line = (
            f"{ts:%Y-%m-%d %H:%M:%S},{ts.microsecond // 1000:03d} {level} [{service}] "
            f"{category}: {rng.choice(MESSAGES[category])} "
            f"(req={rng.getrandbits(32):08x}, user=u{rng.randint(1, 5000):05d}, latency={latency}ms)"
        )
        lines.append(line)
        by_level[level] += 1

        if level == 'ERROR':
            err_cat[category] += 1
            err_svc[service] += 1
            if rng.random() < 0.35:
                pkg = service.split('-')[0]
                for depth in range(rng.randint(2, 4)):
                    lines.append(f"\tat com.logstorm.{pkg}.{category}Handler.step{depth}({category}Handler.java:{rng.randint(20, 400)})")
                    noise['stack trace'] += 1

        if rng.random() < 0.001:
            kind = rng.choice(['vide', 'rotation', 'tronquée'])
            if kind == 'vide':
                lines.append('')
                noise['ligne vide'] += 1
            elif kind == 'rotation':
                lines.append(f"----- log rotated at {ts:%Y-%m-%d %H:%M:%S} -----")
                noise['ligne corrompue'] += 1
            else:
                lines.append(line[: rng.randint(8, 28)])
                noise['ligne corrompue'] += 1

    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')


if not LOG_PATH.exists():
    generate_logs(LOG_PATH)

LOG_URI = LOG_PATH.resolve().as_posix()
raw = sc.textFile(LOG_URI, minPartitions=4)
LOG_PATTERN = re.compile(
    r'^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) '
    r'(?P<level>[A-Z]+) '
    r'\[(?P<service>[\w-]+)\] '
    r'(?P<category>\w+): '
    r'(?P<message>.*?)'
    r'(?: \(req=(?P<req>\w+), user=(?P<user>\w+), latency=(?P<latency>\d+)ms\))?$'
)


def parse_line(line):
    m = LOG_PATTERN.match(line)
    if m is None:
        return None
    return Row(
        ts=m['ts'], level=m['level'], service=m['service'], category=m['category'],
        message=m['message'], user=m['user'],
        latency=int(m['latency']) if m['latency'] else None,
    )

parsed = raw.map(parse_line)
events = parsed.filter(lambda e: e is not None)
errors = events.filter(lambda e: e.level == 'ERROR')

events_by_service = events.map(lambda e: (e.service, 1)).reduceByKey(add)
errors_by_service = errors.map(lambda e: (e.service, 1)).reduceByKey(add).sortBy(lambda kv: kv[1], ascending=False)
print('before join', events_by_service.count(), errors_by_service.count())
error_rate = (
    events_by_service
    .join(errors_by_service)
    .mapValues(lambda t: (t[0], t[1], 100 * t[1] / t[0]))
    .collect()
)
print(error_rate)
