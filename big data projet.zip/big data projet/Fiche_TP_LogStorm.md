# Fiche de TP — LogStorm

## Analyse distribuée de logs et détection d'incidents avec PySpark

| Information | Détail |
|---|---|
| Module | Big Data — Apache Spark / PySpark |
| Durée indicative | 2 à 3 heures |
| Niveau | Initiation/intermédiaire |
| Travail | Individuel ou en binôme |
| Environnement | Python 3.12, Java 17, PySpark 3.5.9, pandas, Matplotlib, Jupyter |

## 1. Objectif du TP

Mettre en œuvre un pipeline de traitement de journaux applicatifs avec PySpark afin de comprendre le traitement distribué et d'extraire des indicateurs utiles au diagnostic d'incidents.

À la fin du TP, vous devrez être capable de :

- distinguer les transformations et les actions Spark;
- créer, lire et manipuler des RDD partitionnés;
- parser des lignes de logs et isoler les données invalides;
- agréger les événements avec des opérations clé/valeur;
- analyser les erreurs par catégorie, service et période;
- détecter un pic anormal d'erreurs et identifier sa cause dominante;
- vérifier la cohérence des résultats par plusieurs méthodes;
- présenter les résultats sous forme de tableaux, fichiers CSV et graphiques.

## 2. Problématique

Une application composée de plusieurs services produit continuellement des logs. Lorsque leur volume augmente, il devient difficile de parcourir les fichiers, de retrouver les erreurs récurrentes et de déterminer quel service est impliqué dans un incident.

Dans ce TP, vous construisez un traitement qui transforme des logs bruts en indicateurs : nombre d'erreurs, catégories et services affectés, activité horaire et détection de fenêtres anormales. Le notebook fonctionne en mode Spark local. Il illustre les mécanismes distribués, mais ne constitue pas un test de performance sur un cluster.

## 3. Prérequis et préparation

Connaissances utiles : bases de Python, fonctions, listes et dictionnaires, lecture de fichiers et notions de données tabulaires.

Prérequis logiciels :

- Python 3.12;
- Java 17 installé et accessible depuis `JAVA_HOME` ou `PATH`;
- les bibliothèques indiquées dans `requirements.txt`;
- Jupyter Notebook ou Jupyter dans VS Code.

Dans PowerShell, depuis le dossier du projet :

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Ouvrir ensuite `LogStorm_Analyse_Logs_PySpark.ipynb`, sélectionner le kernel Python 3.12 de `.venv`, puis exécuter les cellules dans l'ordre. Le notebook génère les données synthétiques si le paramètre `GENERATE` est activé.

## 4. Étapes de réalisation

### Étape 1 — Initialiser Spark et explorer le modèle d'exécution

1. Créer la `SparkSession` et obtenir le `SparkContext`.
2. Afficher le master et le nombre de partitions du RDD d'exemple.
3. Appliquer `map` et `filter`, puis mesurer le temps avant toute action.
4. Appeler `count()` et comparer : expliquer pourquoi le calcul réel démarre au moment de l'action.
5. Afficher le lineage d'un RDD narrow puis celui d'un RDD utilisant `reduceByKey`.

**À retenir :** `map` et `filter` sont des transformations; `count()` est une action. Les opérations wide peuvent entraîner un shuffle.

### Étape 2 — Générer et examiner les données

1. Repérer les paramètres du générateur : nombre d'événements, graine et date.
2. Générer le fichier de logs et `data/ground_truth.json`.
3. Afficher quelques lignes de logs.
4. Identifier les champs présents : horodatage, niveau, service, catégorie et message.
5. Observer les lignes de bruit : stack traces, lignes vides et lignes corrompues.

### Étape 3 — Charger, parser et nettoyer

1. Charger les lignes avec `sc.textFile(...)`.
2. Examiner le nombre de partitions et compter les lignes.
3. Appliquer la regex et la fonction de parsing.
4. Construire le RDD des événements valides et celui des lignes malformées.
5. Mettre en cache les événements réutilisés.
6. Vérifier que le total des lignes valides et rejetées correspond au nombre total de lignes.

### Étape 4 — Analyser les erreurs

1. Filtrer les événements dont le niveau est `ERROR`.
2. Compter les événements par niveau, puis les erreurs par catégorie et par service.
3. Trier les catégories et services selon le nombre d'erreurs.
4. Construire le tableau croisé service × catégorie.
5. Comparer les méthodes `first()`, `max()` et `takeOrdered()` pour trouver les catégories les plus fréquentes.
6. Comparer le premier et le deuxième `count()` après `cache()` pour observer la réutilisation du cache.

### Étape 5 — Étudier l'activité

1. Calculer le nombre total d'événements et d'erreurs pour chaque service.
2. Réaliser une jointure par service et calculer le taux d'erreur.
3. Calculer la latence moyenne par service à partir de la somme et du nombre de mesures.
4. Compter les utilisateurs distincts.
5. Construire le profil horaire : volume d'activité et taux d'erreur.
6. Interpréter les tableaux et le dashboard produit.

### Étape 6 — Détecter et caractériser un incident

1. Regrouper les erreurs en fenêtres de cinq minutes.
2. Calculer la médiane et le MAD des volumes d'erreurs.
3. Appliquer le z-score robuste et le seuil défini dans le notebook.
4. Regrouper les fenêtres anormales consécutives en incidents.
5. Identifier, pour chaque incident, le service et la catégorie les plus représentés.
6. Examiner le tableau des incidents et le graphique `incidents.png`.

### Étape 7 — Vérifier et exporter

1. Recalculer les principaux comptages avec Spark DataFrame/Spark SQL.
2. Refaire les mêmes comptages avec Python séquentiel.
3. Modifier le nombre de partitions et vérifier que les résultats ne changent pas.
4. Comparer les résultats à la vérité terrain.
5. Confirmer que tous les contrôles passent.
6. Vérifier les fichiers écrits dans `output/`.

## 5. Manipulations essentielles

| But | Opération | Résultat à observer |
|---|---|---|
| Créer un RDD | `sc.parallelize(collection, numSlices=...)` | Nombre de partitions contrôlable |
| Charger un fichier | `sc.textFile(path)` | RDD de lignes; lecture déclenchée par une action |
| Transformer les lignes | `map(parse_line)` | Objets structurés ou valeur `None` pour une ligne invalide |
| Filtrer les données | `filter(...)` | Conservation des événements valides ou des événements `ERROR` |
| Agréger par clé | `map((clé, 1)).reduceByKey(add)` | Un comptage par catégorie, service ou heure |
| Mettre en cache | `cache()` puis action | Les analyses suivantes peuvent réutiliser le RDD matérialisé |
| Joindre les comptages | `join(...)` | Numérateur et dénominateur réunis par service |
| Examiner le lineage | `toDebugString()` | Dépendances entre RDD et frontières de shuffle |
| Examiner le plan SQL | `explain()` | Plan physique de la requête Spark SQL |
| Rapporter un résultat | `collect()` | À utiliser uniquement pour des résultats agrégés de petite taille |

**Attention :** éviter `collect()` sur le RDD complet des logs. Cette action rapatrie les données sur le driver et peut saturer sa mémoire.

## 6. Résultats attendus

Les résultats de référence présents dans les fichiers du projet sont :

- **319 377 lignes brutes**;
- **301 500 événements valides**;
- **17 877 lignes rejetées**;
- **16 519 erreurs `ERROR`**, soit environ **5,48 %** des événements valides;
- catégorie la plus fréquente : `TimeoutError`, **4 283 occurrences**;
- service avec le plus d'erreurs : `api-gateway`, **4 514 occurrences**;
- incident principal : **20/10/2026 de 14:10 à 14:25**, cause dominante `payment-service / DatabaseError`.

Dans `incidents.csv`, la période détectée contient 1 777 erreurs, dont 84,9 % attribuées à la cause principale. La vérité terrain indique 1 500 erreurs injectées pour l'incident; les autres erreurs de la période expliquent la différence.

Les sorties attendues dans `output/` comprennent :

- `erreurs_par_categorie.csv`;
- `erreurs_par_service.csv`;
- `activite_par_service.csv`;
- `activite_par_heure.csv`;
- `incidents.csv`;
- `controles_coherence.csv`;
- `dashboard.png` et `incidents.png`.

Les valeurs peuvent changer si les données ou paramètres du générateur sont modifiés. Sur un jeu de taille modeste exécuté en local, Python séquentiel peut être plus rapide que Spark en raison du coût de démarrage et de planification. Ce TP vise à comprendre le modèle Spark et à vérifier les résultats.

## 7. Vérifications à effectuer

- [ ] lignes valides + lignes rejetées = lignes totales;
- [ ] somme des comptages par niveau = nombre d'événements valides;
- [ ] somme des erreurs par catégorie = nombre d'événements `ERROR`;
- [ ] somme des erreurs par service = nombre d'événements `ERROR`;
- [ ] somme du tableau croisé service × catégorie = nombre d'erreurs;
- [ ] somme des parts par catégorie proche de 100 %;
- [ ] résultats identiques après modification du partitionnement;
- [ ] comptages concordants entre RDD, DataFrame/Spark SQL et Python pur;
- [ ] incident détecté couvrant la période et la cause injectées dans la vérité terrain;
- [ ] tous les statuts de `controles_coherence.csv` affichent `OK`;
- [ ] fichiers CSV et graphiques présents dans `output/`.

## 8. Questions d'analyse

1. Quelle est la différence entre une transformation et une action ?
2. Pourquoi `reduceByKey` est-il généralement préférable à `groupByKey` pour compter ?
3. Quelle opération du pipeline provoque un shuffle ? Pourquoi ?
4. Quel est l'intérêt du cache lorsque le même RDD sert à plusieurs analyses ?
5. Pourquoi utiliser la médiane et le MAD pour détecter les anomalies ?
6. Pourquoi Python séquentiel peut-il être plus rapide que Spark sur le jeu de données local ?
7. Quelles adaptations seraient nécessaires pour traiter des logs en continu sur un cluster ?

## 9. Livrables

À remettre :

1. le notebook exécuté, avec les sorties visibles;
2. les exports générés dans `output/`;
3. une courte conclusion présentant la catégorie la plus fréquente, le service le plus touché et l'incident détecté;
4. une réponse aux questions d'analyse, notamment sur les shuffles et la comparaison des performances.

## 10. Barème indicatif

| Critère | Points |
|---|---:|
| Environnement correctement préparé et notebook exécuté | 2 |
| Parsing, filtrage et traitement des lignes invalides | 3 |
| Agrégations et indicateurs d'activité corrects | 3 |
| Détection et interprétation de l'incident | 3 |
| Contrôles de cohérence et comparaison aux références | 3 |
| Explication des concepts Spark et conclusion | 3 |
| Qualité des tableaux, graphiques et livrables | 3 |
| **Total** | **20** |

## Fichiers du projet

- Notebook : [LogStorm_Analyse_Logs_PySpark.ipynb](LogStorm_Analyse_Logs_PySpark.ipynb)
- Dépendances : [requirements.txt](requirements.txt)
- Données de référence : [data/ground_truth.json](data/ground_truth.json)
- Résultats : [output/controles_coherence.csv](output/controles_coherence.csv)
