# LogStorm : analyse distribuée de logs et détection d'incidents

Ce README sert à la fois de guide du projet et de support de préparation pour la présentation PowerPoint. Il décrit le besoin métier, les notions Big Data illustrées, l'architecture, les choix technologiques, les résultats disponibles et les limites du prototype.

La fiche de TP autonome est disponible ici : [Fiche_TP_LogStorm.md](Fiche_TP_LogStorm.md).

## 1. Présentation du projet

LogStorm est un prototype d'analyse de journaux applicatifs avec Apache Spark et PySpark. Il lit des logs horodatés, extrait les événements exploitables, analyse les erreurs par catégorie et par service, étudie l'activité dans le temps et signale les pics anormaux pouvant correspondre à un incident.

Le jeu de données est synthétique et reproductible. Il contient des événements normaux, des erreurs et des lignes bruitées (stack traces, lignes vides ou corrompues). Un incident connu est injecté afin de comparer la détection à une vérité terrain indépendante.

**Objectif métier :** aider une équipe d'exploitation ou SRE à répondre rapidement à trois questions :

- Quelles erreurs sont les plus fréquentes ?
- Quels services et quelles périodes sont les plus affectés ?
- Un pic d'erreurs correspond-il à un incident identifiable ?

## 2. Problématique métier

Dans une application distribuée, chaque service produit des journaux en continu. Une analyse manuelle ou un script séquentiel devient difficile à mesure que le volume augmente : il faut lire et filtrer beaucoup de lignes, les structurer, agréger les résultats et relier les symptômes au service concerné.

Le besoin est donc de construire un traitement reproductible qui transforme des logs bruts en indicateurs compréhensibles pour le diagnostic : fréquence des erreurs, taux d'erreur par service, activité horaire, fenêtres anormales et cause probable d'un incident.

Le traitement distribué apporte une réponse lorsque le volume dépasse les ressources d'une seule machine : les données sont découpées en partitions, traitées en parallèle et les agrégats sont recombinés. Le projet utilise Spark en mode local pour illustrer cette architecture, pas pour prétendre démontrer un gain de performance sur un cluster réel.

## 3. Concepts techniques du chapitre

| Concept | Explication | Exemple dans LogStorm |
|---|---|---|
| RDD | Collection immuable et partitionnée traitée par Spark | `sc.textFile(...)` charge les lignes du fichier |
| Partition | Sous-ensemble de données confié à une tâche | Le fichier est lu avec plusieurs partitions |
| Transformation | Opération qui construit un nouveau RDD sans lancer immédiatement le calcul | `map`, `filter`, `reduceByKey` |
| Action | Opération qui déclenche le calcul et produit un résultat | `count`, `collect`, `take`, `first` |
| Lazy evaluation | Spark attend une action avant d'exécuter la chaîne de transformations | Démonstration `map` / `filter` puis `count()` |
| DAG et stages | Graphe du traitement, séparé en étapes aux frontières de shuffle | Lineage affiché avec `toDebugString()` |
| Narrow / wide | Une transformation narrow travaille localement; une wide peut redistribuer les données | `filter` est narrow; `reduceByKey` et `join` impliquent un shuffle |
| Shuffle | Redistribution des données, généralement par clé, entre partitions | Comptages par catégorie et jointure par service |
| Cache | Conservation en mémoire d'un RDD réutilisé | Les événements valides et les erreurs sont réutilisés dans plusieurs analyses |
| Lineage | Recette de calcul permettant de reconstruire une partition perdue | Dépendances successives des RDD depuis les logs bruts |
| Broadcast | Variable diffusée efficacement aux executors | Ensemble des fenêtres d'incident partagé pour qualifier les erreurs |

**Point pédagogique important :** une transformation Spark n'est pas nécessairement exécutée au moment où elle apparaît dans le code. Une action déclenche l'exécution du DAG. `collect()` ne doit servir qu'à rapatrier de petits résultats agrégés, pas un grand jeu de données entier.

## 4. Architecture de la solution

```mermaid
flowchart LR
    A[Logs synthétiques<br/>data/app_logs.log] --> B[Lecture distribuée<br/>RDD Spark]
    B --> C[Parsing regex<br/>et séparation du bruit]
    C --> D[Événements valides<br/>et erreurs ERROR]
    D --> E[Comptages par niveau,<br/>catégorie et service]
    D --> F[Activité par heure<br/>taux et latence]
    D --> G[Fenêtres de 5 minutes<br/>score robuste d'anomalie]
    E --> H[Tableaux, graphiques<br/>et fichiers CSV]
    F --> H
    G --> H
    H --> I[Contrôles de cohérence<br/>RDD, SQL, Python, vérité terrain]
```

### Étapes du pipeline

1. Générer ou charger le fichier de logs et sa vérité terrain.
2. Lire les lignes en RDD Spark et examiner un échantillon.
3. Parser les lignes avec une expression régulière; isoler les lignes valides et les lignes rejetées.
4. Filtrer les événements `ERROR`, puis compter par catégorie, service, heure et combinaison service-catégorie.
5. Calculer des indicateurs d'activité, dont le taux d'erreur par service et la latence moyenne.
6. Regrouper les erreurs en fenêtres de cinq minutes et détecter les valeurs anormales par z-score robuste basé sur la médiane et le MAD.
7. Regrouper les fenêtres anormales contiguës en incidents et rechercher leur cause dominante.
8. Vérifier les résultats par plusieurs méthodes et exporter les tableaux et graphiques.

## 5. Choix technologiques et justification

| Technologie | Rôle et justification |
|---|---|
| Python 3.12 | Interpréteur utilisé pour le notebook; choisi pour la compatibilité avec PySpark dans l'environnement Windows du projet. |
| Apache Spark / PySpark 3.5.9 | Traitement distribué et démonstration des RDD, transformations, actions, shuffles, cache, DAG et lineage. |
| pandas | Mise en forme des petits résultats agrégés, tableaux croisés et données exportées. |
| Matplotlib | Création du tableau de bord et de la courbe d'incidents. |
| Java 17 | Environnement d'exécution nécessaire à Spark. |
| Jupyter Notebook | Support pédagogique qui réunit explications, code, résultats et visualisations. |
| CSV et JSON | Formats simples pour consulter les résultats et conserver la vérité terrain. |

Spark est retenu pour illustrer le traitement distribué et préparer une logique transposable à un cluster. Pandas est limité à la présentation des agrégats, qui sont petits. Le notebook emploie aussi l'API DataFrame/Spark SQL pour comparer cette approche à l'API RDD.

## 6. Résultats disponibles

Les fichiers d'export présents dans `output/` et la vérité terrain dans `data/ground_truth.json` donnent les chiffres suivants :

> **État de vérification :** ces chiffres proviennent des fichiers d'export et de vérité terrain actuellement présents dans le projet. Dans l'état courant, les cellules du notebook ne sont pas marquées comme exécutées dans le kernel. Avant la présentation, exécuter le notebook de haut en bas et vérifier que les exports sont à jour.

- **319 377 lignes brutes** examinées.
- **301 500 événements valides** après parsing.
- **17 877 lignes rejetées**, principalement des stack traces (17 544), ainsi que 221 lignes corrompues et 112 lignes vides.
- **16 519 événements ERROR**, soit environ **5,48 %** des événements valides.
- La catégorie la plus fréquente est `TimeoutError` : **4 283 erreurs** (25,93 %).
- Le service avec le plus grand nombre d'erreurs est `api-gateway` : **4 514 erreurs** (27,33 %).
- Un incident est détecté du **20 octobre 2026 à 14:10 à 14:25**, sur `payment-service / DatabaseError`. L'export le caractérise par 1 777 erreurs, environ 12,2 fois le niveau normal estimé; 84,9 % des erreurs de l'incident correspondent à la cause principale.
- Les contrôles exportés comparent les invariants, le partitionnement, Spark SQL/DataFrame, Python séquentiel et la vérité terrain. Les lignes actuellement disponibles dans `controles_coherence.csv` sont au statut **OK**.

La vérité terrain indique que 1 500 erreurs d'incident ont été injectées. Le total détecté pour la période inclut aussi les autres erreurs survenues dans les fenêtres identifiées, d'où un nombre supérieur dans `incidents.csv`.

### Fichiers de sortie

- [output/erreurs_par_categorie.csv](output/erreurs_par_categorie.csv) : fréquence et part de chaque catégorie.
- [output/erreurs_par_service.csv](output/erreurs_par_service.csv) : nombre d'erreurs par service.
- [output/activite_par_service.csv](output/activite_par_service.csv) : activité, taux d'erreur et latence moyenne par service.
- [output/activite_par_heure.csv](output/activite_par_heure.csv) : activité et taux d'erreur par heure.
- [output/incidents.csv](output/incidents.csv) : période, durée, volume, facteur d'écart et cause principale des incidents.
- [output/controles_coherence.csv](output/controles_coherence.csv) : résultats des contrôles de validation.
- [output/dashboard.png](output/dashboard.png) : visualisation de l'activité générale.
- [output/incidents.png](output/incidents.png) : visualisation des fenêtres anormales et incidents.

## 7. Limites et améliorations possibles

- **Données synthétiques :** elles permettent de contrôler le résultat, mais ne représentent pas toute la variabilité des logs de production.
- **Exécution locale :** `local[*]` utilise un seul ordinateur. Le projet ne mesure ni la montée en charge ni la tolérance aux pannes d'un vrai cluster.
- **Volume de test :** les fichiers actuels sont utiles à une démonstration, mais insuffisants pour prouver un avantage de performance distribué. Le notebook indique qu'un traitement Python séquentiel est plus rapide sur l'échantillon local, car le coût de démarrage de Spark domine.
- **Parsing dépendant du format :** une évolution du format de log peut nécessiter une mise à jour de la regex.
- **Seuil d'anomalie fixe :** le z-score robuste utilise un seuil constant et ne modélise pas explicitement la saisonnalité ni les différences de trafic entre services.
- **Traitement par fichier :** il n'y a pas encore de flux temps réel, d'alertes automatiques, de stockage distribué ni de tableau de bord interactif.
- **Latence d'observation :** les moyennes et regroupements donnent une vue synthétique et peuvent masquer des distributions ou des cas rares.

Évolutions possibles : tester sur des logs réels anonymisés, utiliser Spark Structured Streaming avec Kafka, stocker les données en Parquet sur HDFS ou S3, définir des seuils par service et ajouter une interface de supervision.

## 8. Préparation de l'environnement et lancement

### Prérequis

- Windows, macOS ou Linux;
- Python 3.12 recommandé pour l'environnement utilisé par ce projet;
- Java 17 installé et accessible via `JAVA_HOME` / `PATH`;
- Jupyter Notebook ou Jupyter dans VS Code.

### Installation sous Windows PowerShell

Depuis le dossier du projet :

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Ouvrir ensuite [LogStorm_Analyse_Logs_PySpark.ipynb](LogStorm_Analyse_Logs_PySpark.ipynb), sélectionner le kernel Python 3.12 de `.venv`, puis exécuter les cellules dans l'ordre, du début à la fin. La première exécution génère ou actualise les données selon le paramètre `GENERATE` défini dans le notebook. Les résultats sont écrits dans `output/`.

## 9. Plan de présentation PowerPoint

Cette proposition peut être reprise directement en diapositives. Ajouter les captures du notebook et les graphiques exportés dans `output/`.

### Diapositive 1 — Titre et objectif

**LogStorm : analyse distribuée de logs et détection d'incidents**

Présenter l'objectif : transformer un grand volume de journaux applicatifs en indicateurs utiles au diagnostic et détecter des pics d'erreurs.

### Diapositive 2 — Problématique métier

- Les applications et microservices produisent des logs en continu.
- L'analyse manuelle devient difficile quand le volume augmente.
- Les équipes doivent identifier les erreurs récurrentes, les services affectés et le moment d'un incident.
- Le besoin : un pipeline fiable, reproductible et extensible.

**À dire :** « L'enjeu n'est pas seulement de compter les erreurs, mais de transformer les logs en informations qui accélèrent le diagnostic. »

### Diapositive 3 — Pourquoi le traitement distribué ?

- Un script classique est limité par la mémoire, le processeur et les entrées/sorties d'une machine.
- Spark répartit les données en partitions et exécute les tâches en parallèle.
- Le lineage permet de reconstruire des partitions perdues.
- Le prototype s'exécute en local pour l'apprentissage; le mode cluster est une perspective.

### Diapositive 4 — Concepts Spark illustrés

Présenter RDD, partitions, transformations/actions, lazy evaluation, DAG, stages, narrow/wide, shuffle, cache et lineage.

**Exemple à commenter :** `map` et `filter` construisent le plan; `count()` lance le calcul. `reduceByKey` agrège les erreurs par clé et implique une redistribution (shuffle).

### Diapositive 5 — Architecture de la solution

Reprendre le diagramme de la section 4 : logs → lecture RDD → parsing/filtrage → agrégations et détection → validations → CSV et graphiques.

Préciser que le notebook compare aussi RDD, DataFrame/Spark SQL et un calcul de référence en Python pur.

### Diapositive 6 — Choix technologiques

- PySpark 3.5.9 et Java 17 pour le moteur Spark.
- Python 3.12 pour la compatibilité de l'environnement Windows.
- pandas pour les petits résultats agrégés; Matplotlib pour les graphiques.
- Jupyter pour associer démonstrations, code et explications.

Justifier que Spark est choisi pour étudier les concepts Big Data, et non parce qu'il est forcément plus rapide sur un petit fichier.

### Diapositive 7 — Implémentation du pipeline

- Génération reproductible de logs et d'une vérité terrain.
- Parsing regex et séparation des lignes invalides.
- Comptages par niveau, catégorie, service et heure.
- Calcul de taux d'erreur, latence et utilisateurs distincts.
- Mise en cache des RDD réutilisés.

### Diapositive 8 — Détection d'incident

- Regroupement des erreurs en fenêtres de cinq minutes.
- Calcul du z-score robuste à partir de la médiane et du MAD.
- Marquage des fenêtres dont le score dépasse 3,5.
- Regroupement des fenêtres consécutives puis recherche de la cause dominante.

Afficher `output/incidents.png` et présenter l'incident détecté sur `payment-service`.

### Diapositive 9 — Résultats et validation

- 319 377 lignes brutes; 301 500 événements valides.
- 16 519 erreurs, soit environ 5,48 % des événements valides.
- `TimeoutError` est la catégorie la plus fréquente (4 283 occurrences).
- `api-gateway` a le plus grand nombre d'erreurs (4 514).
- Incident du 20/10/2026 de 14:10 à 14:25 : `payment-service / DatabaseError`.
- Contrôles croisés avec Spark SQL, Python pur, autre partitionnement et vérité terrain.

Afficher `output/dashboard.png` et un extrait de `output/controles_coherence.csv`.

### Diapositive 10 — Limites, perspectives et conclusion

- Données synthétiques et exécution sur une seule machine.
- Le coût fixe de Spark peut le rendre plus lent que Python sur cet échantillon.
- Prochaines étapes : cluster réel, logs réels anonymisés, stockage Parquet, streaming Kafka et alertes.

**Conclusion à dire :** « Le projet met en œuvre une chaîne complète d'analyse et vérifie ses résultats. Il illustre les mécanismes Spark et fournit une base à faire évoluer vers une supervision temps réel. »

## 10. Questions possibles à l'oral

**Pourquoi Spark si Python séquentiel est plus rapide ici ?**  
Parce que ce jeu de données tient sur une seule machine. Spark a un coût de démarrage; son intérêt apparaît lorsque le volume ou le débit dépasse les capacités d'une machine et que le calcul peut être réparti.

**Pourquoi utiliser `reduceByKey` plutôt que `groupByKey` ?**  
`reduceByKey` effectue une pré-agrégation locale avant le shuffle et ne transmet que des sommes partielles. `groupByKey` déplace toutes les valeurs d'une clé avant de les agréger.

**Pourquoi utiliser médiane et MAD pour les anomalies ?**  
Ils sont moins sensibles aux valeurs extrêmes que la moyenne et l'écart-type. Un incident ne gonfle donc pas autant le seuil qu'il pourrait masquer.

**Comment les résultats sont-ils validés ?**  
Les invariants sont contrôlés, les comptages sont recalculés via DataFrame/Spark SQL et Python pur, le partitionnement varie, puis les valeurs sont comparées à la vérité terrain.

## Références du projet

- Notebook principal : [LogStorm_Analyse_Logs_PySpark.ipynb](LogStorm_Analyse_Logs_PySpark.ipynb)
- Dépendances : [requirements.txt](requirements.txt)
- Logs : [data/app_logs.log](data/app_logs.log)
- Vérité terrain : [data/ground_truth.json](data/ground_truth.json)

## 11. L4 — Fiche de TP

### Intitulé

**Analyse distribuée de journaux applicatifs avec PySpark et détection d'incidents**

### Objectif du TP

À la fin du TP, l'étudiant doit être capable de :

- expliquer la différence entre une transformation et une action Spark;
- créer et manipuler un RDD partitionné;
- structurer des lignes de logs avec une expression régulière et écarter les lignes invalides;
- utiliser `map`, `filter`, `reduceByKey`, `join`, `cache` et les actions adaptées;
- produire des statistiques par niveau, catégorie, service et période;
- identifier des fenêtres temporelles anormales et les regrouper en incidents;
- contrôler les résultats par comparaison entre plusieurs méthodes indépendantes;
- exporter des résultats lisibles sous forme de tableaux CSV et de graphiques.

### Durée et prérequis

Durée indicative : **2 à 3 heures**. Il est recommandé de connaître les bases de Python, les dictionnaires et fonctions, ainsi que les notions de fichiers CSV et de traitement de données.

Environnement : Python 3.12, Java 17, PySpark 3.5.9, pandas, Matplotlib et Jupyter. Les étapes d'installation sont décrites à la section 8 de ce README. Le TP est conçu pour fonctionner en mode Spark local sur Windows.

### Étapes de réalisation

1. **Préparer l'environnement**
    - Installer les dépendances depuis `requirements.txt`.
    - Ouvrir le notebook et choisir le kernel Python 3.12.
    - Exécuter les cellules dans l'ordre, de haut en bas.

2. **Initialiser Spark et observer les RDD**
    - Créer la `SparkSession` et récupérer le `SparkContext`.
    - Observer le nombre de partitions et le master local.
    - Exécuter la démonstration `map` / `filter`, puis `count()` pour constater la lazy evaluation.
    - Comparer le lineage d'une chaîne narrow à celui d'une agrégation utilisant `reduceByKey`.

3. **Créer et examiner les données**
    - Utiliser le générateur du notebook pour créer les logs synthétiques et la vérité terrain.
    - Examiner quelques lignes du fichier et repérer le format de timestamp, niveau, service et catégorie.
    - Identifier le bruit ajouté : stack traces, lignes corrompues et lignes vides.

4. **Charger, parser et nettoyer**
    - Lire le fichier avec `sc.textFile`.
    - Appliquer la fonction de parsing pour convertir les lignes valides en événements structurés.
    - Séparer les événements exploitables des lignes rejetées et vérifier les totaux.
    - Mettre en cache les RDD réutilisés dans plusieurs analyses.

5. **Analyser les erreurs et l'activité**
    - Filtrer les événements `ERROR`.
    - Compter et classer les erreurs par catégorie et par service avec `reduceByKey`.
    - Construire le tableau croisé service-catégorie.
    - Calculer le taux d'erreur, la latence moyenne, les utilisateurs distincts et le profil horaire.
    - Comparer les résultats obtenus avec des actions comme `first`, `max` et `takeOrdered`.

6. **Détecter un incident**
    - Regrouper les erreurs en fenêtres de cinq minutes.
    - Calculer le score robuste à partir de la médiane et du MAD, avec le seuil configuré dans le notebook.
    - Regrouper les fenêtres anormales consécutives et déterminer le service et la catégorie les plus représentés.
    - Examiner le tableau des incidents et le graphique temporel.

7. **Vérifier puis exporter**
    - Recalculer les statistiques avec Spark DataFrame/Spark SQL et avec Python séquentiel.
    - Vérifier les invariants et comparer les résultats à la vérité terrain.
    - Confirmer que tous les contrôles affichent `OK`.
    - Vérifier les fichiers CSV et images produits dans `output/`.

### Manipulations essentielles

| Manipulation | Opération ou API | Observation attendue |
|---|---|---|
| Créer un RDD depuis une collection | `sc.parallelize(...)` | Le RDD est découpé en partitions consultables avec `getNumPartitions()` |
| Lire les logs | `sc.textFile(...)` | Les lignes sont distribuées; une action comme `count()` déclenche leur lecture |
| Structurer les lignes | `map(parse_line)` puis `filter(...)` | Les lignes valides deviennent des événements, les autres sont écartées |
| Compter par clé | `map(lambda e: (e.category, 1)).reduceByKey(add)` | Un total est calculé pour chaque catégorie après shuffle |
| Comparer cache et recalcul | `cache()` puis deux appels à `count()` | Le deuxième comptage réutilise les données matérialisées en cache |
| Joindre deux statistiques | `join(...)` sur le service | Le volume d'événements et le nombre d'erreurs permettent de calculer un taux |
| Observer le DAG | `toDebugString()` et `explain()` | Le lineage et le plan SQL montrent les étapes et échanges de données |
| Détecter des anomalies | fenêtres de 5 minutes, médiane, MAD et broadcast | Les fenêtres anormales sont regroupées et associées à une cause dominante |
| Contrôler les résultats | invariants et recalculs indépendants | Les comptages doivent concorder entre RDD, SQL, Python et vérité terrain |

**Consigne de prudence :** ne pas utiliser `collect()` sur les événements bruts. Dans ce TP, il est réservé aux petits résultats agrégés; les données principales doivent rester distribuées dans Spark.

### Résultats attendus

Les valeurs suivantes correspondent aux fichiers de référence présents dans le projet. Une exécution peut produire des différences si les paramètres ou les données ont été modifiés.

- Total de **319 377 lignes** dans le fichier.
- **301 500 événements valides** et **17 877 lignes rejetées**.
- **16 519 erreurs `ERROR`**, environ **5,48 %** des événements valides.
- `TimeoutError` est la catégorie la plus fréquente avec **4 283 occurrences**.
- `api-gateway` compte le plus grand nombre d'erreurs avec **4 514 occurrences**.
- L'incident injecté doit être retrouvé autour de **14:10–14:25**, avec la cause principale `payment-service / DatabaseError`.
- Les résultats de comptage doivent concorder entre RDD, Spark SQL/DataFrame, Python séquentiel et vérité terrain.
- Les fichiers d'analyse doivent apparaître dans `output/`, notamment les CSV d'activité, de catégories, de services, d'incidents et de cohérence.

Sur ce volume local, Python séquentiel peut être plus rapide que Spark : le temps de démarrage et de planification Spark est significatif. Le but du TP est d'apprendre le modèle distribué et de vérifier le pipeline, pas de démontrer une accélération sur un petit échantillon.

### Vérifications à effectuer

- Le nombre de lignes valides plus le nombre de lignes rejetées est égal au nombre total de lignes.
- La somme des événements par niveau est égale au nombre d'événements valides.
- La somme des erreurs par catégorie et par service est égale au nombre d'événements `ERROR`.
- La somme du tableau croisé service-catégorie est égale au nombre d'erreurs.
- La somme des parts par catégorie est proche de 100 %.
- Le résultat des comptages ne change pas lorsque le nombre de partitions est modifié.
- Les comptages Spark RDD, DataFrame/Spark SQL et Python pur sont identiques.
- La catégorie et la période de l'incident détecté couvrent celles inscrites dans `data/ground_truth.json`.
- Tous les statuts de `output/controles_coherence.csv` sont `OK`.
- Les graphiques et exports attendus existent et sont lisibles.

### Livrables à remettre

- Le notebook exécuté avec ses résultats visibles.
- Les fichiers exportés du dossier `output/`.
- Une courte conclusion indiquant la catégorie la plus fréquente, le service le plus touché et la cause principale de l'incident.
- Une remarque sur la différence de performance observée entre Spark local et Python séquentiel, en la reliant au volume testé.